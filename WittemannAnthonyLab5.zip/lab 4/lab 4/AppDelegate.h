//
//  AppDelegate.h
//  lab 4
//
//  Created by Anthony Wittemann on 3/14/16.
//  Copyright © 2016 Anthony Wittemann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

