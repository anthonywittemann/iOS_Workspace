//
//  main.m
//  Lab3_AW
//
//  Created by Anthony Wittemann on 2/8/16.
//  ****************USING 3 late days**********************
//  Copyright © 2016 Anthony Wittemann. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
