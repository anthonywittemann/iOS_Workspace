//
//  AppDelegate.h
//  Lab1_AW
//
//  Created by Anthony Wittemann on 1/13/16.
//  Copyright © 2016 Anthony Wittemann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

