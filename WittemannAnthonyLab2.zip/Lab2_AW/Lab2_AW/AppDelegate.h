//
//  AppDelegate.h
//  Lab2_AW
//
//  Created by Anthony Wittemann on 1/25/16.
//  Copyright © 2016 Anthony Wittemann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

